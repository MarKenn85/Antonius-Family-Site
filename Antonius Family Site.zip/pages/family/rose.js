window.rosePage = {
    name: "AutumnRose Antonius",
    title: "Daughter of Rome",
    parent: "gamilla",
    portrait: "images/portraits/rose.png",
    next: "frederick",
    previous: "taurus",
    text: [
      `
        <p>
        An Unwritten Chapter
        <br>
        <br>
        Not every story has yet been committed to parchment.
        <br>
        <br>
        Some members of House Antonius still walk their paths, adding new pages with each passing season. Their histories remain unwritten not because they are forgotten, but because their tales are still unfolding.
        <br>
        <br>
        When the ink is ready, this space shall be filled.
        <br>
        <br>
        Until then, let it stand as a reminder that our family is not merely history.
        <br>
        <br>
        It is still being written.
        </p>
      `
    ]
  };