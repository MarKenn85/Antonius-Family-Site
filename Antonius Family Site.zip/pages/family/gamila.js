window.gamilaPage = {
    name: "Gamila Antonius",
    title: "Daughter of the Sun",
    parent: "helios",
    portrait: "images/portraits/gamila.png",
    next: "gage",
    previous: "batresh",
    text: [
      `
        <p>
        An Unwritten Chapter
        <br>
        <br>
        Not every story has yet been committed to parchment.
        <br>
        <br>
        Some members of House Antonius still walk their paths, adding new pages with each passing season. Their histories remain unwritten not because they are forgotten, but because their tales are still unfolding.
        <br>
        <br>
        When the ink is ready, this space shall be filled.
        <br>
        <br>
        Until then, let it stand as a reminder that our family is not merely history.
        <br>
        <br>
        It is still being written.
        </p>
      `
    ]
  };